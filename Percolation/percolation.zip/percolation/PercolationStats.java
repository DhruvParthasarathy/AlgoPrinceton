import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;


public class PercolationStats {
	final private double[] percolateFraction;
    // perform independent trials on an n-by-n grid
	final private int trials;
    public PercolationStats(int n, int trials) {
    	this.trials=trials;
    	percolateFraction=new double[trials];
    	for(int index=0;index<trials;index++) {
    		Percolation impl = new Percolation(n);
            while (!impl.percolates()) {
                int row = StdRandom.uniform(1,n+1);
                int col = StdRandom.uniform(1,n+1);
                impl.open(row, col);
            }
    		percolateFraction[index] = ((double)impl.numberOfOpenSites())/(n*n);
    	}
    }
    // sample mean of percolation threshold
    public double mean() {
    	return StdStats.mean(percolateFraction);
    }
    
    // sample standard deviation of percolation threshold
    public double stddev() {
    	return StdStats.stddev(percolateFraction);
    }
    // low endpoint of 95% confidence interval
    public double confidenceLo() {
    	return ( mean() - (1.96*stddev())/Math.sqrt(trials) );
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
    	return ( mean() + (1.96*stddev())/Math.sqrt(trials) );
    }

	public static void main(String[] args) {
		int gridSize = 4;
		int trialCount =4;
		if (args.length >= 2) {
			gridSize = Integer.parseInt(args[0]);
			trialCount = Integer.parseInt(args[1]);
		}
		if (gridSize <= 0 || trialCount <= 0) {
            throw new IllegalArgumentException("N and T must be >= 0");
        }
		PercolationStats ps = new PercolationStats(gridSize, trialCount);
		String confidence = "["+ps.confidenceLo() + ", " + ps.confidenceHi()+"]";
        System.out.println("mean                    = " + ps.mean());
        System.out.println("stddev                  = " + ps.stddev());
        System.out.println("95% confidence interval = " + confidence);
	   }
     
}