import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
	final private int dim;
	private int currentRow;
	private int currentCol;
	final private WeightedQuickUnionUF unionFind;
	private  int countOfOpenSites;
	private boolean[][] siteOpen;
	private boolean[][] siteFull;
	
	public Percolation(int n) {
		this.dim = n;
		siteOpen=new boolean[n][n];
		siteFull=new boolean[n][n];
		for (int row = 0; row < n; row++) {
			for (int col = 0; col < n; col++) {
				siteOpen[row][col]=false;
				siteFull[row][col]=false;
			}
		}
		unionFind = new WeightedQuickUnionUF(n * n + 2);
	}



	// opens the site (row, col) if it is not open already
	public void open(int row, int col) {
		row=row-1;
		col=col-1;
		validateSite(row,col);
		if (!siteOpen[row][col]) {
			siteOpen[row][col] = true;
			if(row==0) {
				siteFull[row][col] = true;
				unionFind.union(twoDtoOneDConv(row,col),0);
			}
			if(row==dim-1) {
				unionFind.union(twoDtoOneDConv(row,col),1);
			}
			this.currentRow = row;
			this.currentCol = col;
			countOfOpenSites++;
			checkSiteForConnection();
		}
	}

	// is the site (row, col) open?
	public boolean isOpen(int row, int col) {
		validateSite(row-1,col-1);
		return siteOpen[row-1][col-1];
	}

	// is the site (row, col) full?
	public boolean isFull(int row, int col) {
		validateSite(row-1,col-1);
		int array[]=getParentLinearIndex(twoDtoOneDConv(row-1,col-1));
		return siteFull[array[0]][array[1]];
	}

	// returns the number of open sites
	public int numberOfOpenSites() {
		return countOfOpenSites;
	}

	// does the system percolate?
	public boolean percolates() {
		int[] topArr=oneDToTwoDConv(unionFind.find(0));
		int[] bottomArr=oneDToTwoDConv(unionFind.find(1));
		if(topArr[0]==bottomArr[0]&&topArr[1]==bottomArr[1]&&siteFull[bottomArr[0]][bottomArr[1]])
			return true;
		else return false;
	}
	
	private void checkSiteForConnection() {
		if (currentRow - 1 >= 0) {
			siteConnection(currentRow - 1, currentCol);
		}
		if (currentRow + 1 < dim) {
			siteConnection(currentRow + 1, currentCol);
		}
		if (currentCol - 1 >= 0) {
			siteConnection(currentRow, currentCol - 1);
		}
		if (currentCol + 1 < dim) {
			siteConnection(currentRow, currentCol + 1);
		}
	}

	private void siteConnection(int row, int col) {
		if (isOpen(row+1, col+1)) {
			int adjSiteIndex=twoDtoOneDConv(row, col);
			int currentSiteIndex=twoDtoOneDConv(currentRow, currentCol);
			int[] adjRowColP = getParentLinearIndex(adjSiteIndex);
			int[] CurrRowColP = getParentLinearIndex(currentSiteIndex);
			if(isFull(adjRowColP[0]+1,adjRowColP[1]+1)&&(!isFull(row+1,col+1)))
				siteFull[row][col]=true;
			if(isFull(CurrRowColP[0]+1,CurrRowColP[1]+1)&&(!isFull(currentRow+1,currentCol+1))) {
				siteFull[currentRow][currentCol]=true;
			}
			if(isFull(row+1,col+1)||isFull(currentRow+1,currentCol+1)) {
				if(isFull(row+1,col+1)) {
					siteFull[currentRow][currentCol]=true;
					siteFull[CurrRowColP[0]][CurrRowColP[1]]=true;
				}
				else {
					siteFull[row][col]=true;
					siteFull[adjRowColP[0]][adjRowColP[1]]=true;
				}
			}
			unionFind.union(currentSiteIndex, adjSiteIndex);
		}
	}
	private int[] getParentLinearIndex(int linearIndex) {
		int parentOfSite = unionFind.find(linearIndex);
		int[] siteOfP = oneDToTwoDConv(parentOfSite);
		return siteOfP;
	}


	private int twoDtoOneDConv(int row, int col) {
		return row * dim + col + 2;
	}
	
	private int[] oneDToTwoDConv(int index) {
		index=index-2;
		int[] array = {index/dim,index%dim};
		return array;
	}

//	private boolean OpenRandomSite() {
//		boolean randomSiteFound = false;
//		while (!randomSiteFound) {
//			int row = StdRandom.uniform(dim);
//			int col = StdRandom.uniform(dim);
//			if (!isOpen(row, col)) {
//				
//				open(row,col);
//				randomSiteFound=true;
//			}
//		}
//		return true;
//	}

	 private boolean isOnGrid(int row, int col) {
	        return (row >= 0 && col >= 0 && row < dim && col <dim);
	 }
	 
	 private void validateSite(int row, int col) {
	        if (!isOnGrid(row, col)) {
	            throw new IllegalArgumentException("Illegal Argument Please Check Input");
	        }
	    }

	
}
